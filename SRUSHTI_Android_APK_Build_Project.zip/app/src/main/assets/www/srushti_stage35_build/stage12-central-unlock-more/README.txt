STAGE 12 — CENTRAL 90% UNLOCK EXTENSION

Central mastery sequential checks added to:
- Step 3 Foundation Lessons: topic order within each subject
- Step 19 RBI Grade B Foundation: lesson sequence
- Step 20 Interview Preparation: lesson sequence
- Step 21 SBI/IBPS PO: previous lesson pass check at quiz submission
- Step 22 Computer Awareness: previous lesson pass check at quiz submission

Legacy passed records are imported into the common ledger where applicable.
Steps 21/22 guard quiz submission; lesson content remains visible. This is not full content concealment.
Steps 3, 19, 20 have lesson opening guards. Existing local module progress is retained.
Not all app modules are fully gated; manual end-to-end browser testing remains necessary.
