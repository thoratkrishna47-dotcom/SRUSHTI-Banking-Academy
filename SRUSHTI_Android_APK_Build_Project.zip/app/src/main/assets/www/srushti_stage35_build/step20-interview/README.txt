SRUSHTI – STEP 20: INTERVIEW PREPARATION & PERSONALITY DEVELOPMENT
Starter version 1.0 | Cost: ₹0

FILES
- index.html
- interview_lessons.json
- README.txt

CONTENTS
10 interview preparation lessons and 50 original MCQs:
1. Interview overview and preparation
2. Self-introduction
3. Why Banking?
4. Banking basics
5. Situational questions, customer complaints and ethics
6. Communication skills and body language
7. Current affairs and banking awareness in interview
8. Strengths, weaknesses and career goals
9. Mock interview and self-evaluation
10. Interview etiquette and final preparation

FEATURES
- Marathi explanations and English answer examples
- 50 original MCQs with explanations
- 90% pass gate; with five questions, 5/5 are needed
- Unlimited attempts and sequential unlock
- Browser-local progress
- Self-practice question picker and answers saved locally

LIMITATIONS
- Starter practice module, not a guarantee of selection.
- No live interviewer, AI answer scoring, speech recognition, video recording or pronunciation scoring.
- Model answers are frameworks; personalize them truthfully. Never claim experience or qualifications you do not have.
- Interview stages and weightage differ by recruitment and notification. Check the official recruitment notice.
- Current affairs and rates change; verify with official sources before interview.
- Standalone; not integrated with Steps 1–19.
- Browser data clearing may erase progress and saved practice answers.
- No paid API, hosting, subscription or external paid service used.
