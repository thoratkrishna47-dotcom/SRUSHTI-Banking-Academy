STAGE 16 — STUDENT PROFILE & PERSONAL STUDY GOALS

Added student-profile.html and a Home dashboard link.
Features:
- Student display name, target exam, goal statement and optional target date.
- Editable daily study target (0.5–16 hours) and weekly target (1–112 hours).
- Manual study-session logging by date, subject and minutes.
- Daily and current Monday–Sunday weekly progress bars and totals.
- Recent study log and JSON export.
- Local storage keys: sru_profile_v1 and sru_goal_log_v1 (included in Stage 15 full backup filter).

Limitations:
- No sign-in, cloud sync, multi-device sync or account recovery.
- Study time is manually entered and is not automatically imported from other modules.
- Weekly total is calculated Monday through current date.
- No exam date predictions or claims of guaranteed selection.
- Browser end-to-end test is still required.
