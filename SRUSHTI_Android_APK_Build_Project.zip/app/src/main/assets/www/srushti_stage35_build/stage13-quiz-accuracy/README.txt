STAGE 13 — QUIZ ACCURACY & GRANULAR MASTERY REPORTING

Fix:
- Step 6 Current Affairs monthly quiz now grades answers against the same randomized order displayed to the learner. Previously, the displayed order was shuffled but grading used the original order, potentially marking correct answers incorrectly.

Reporting enhancements:
- Step 14 PYQ-pattern practice continues to record the overall attempt and now also records subject-wise attempts for subjects present in that session.
- Step 15 Mock Simulator continues to record the overall mock and now also records section-wise attempts (correct / total questions) for each section.

These enhancements improve diagnosis in the Common Mastery Centre. They do not lock practice or full mocks; practice and mock availability should remain open for exam readiness.
Browser end-to-end testing with user-created current-affairs data and multiple randomized runs is still required.
