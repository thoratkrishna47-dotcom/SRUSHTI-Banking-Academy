SRUSHTI Step 13 – Advanced Maths & Advanced Reasoning

10 starter lessons (5 per section):
Advanced Maths:
1 Quadratic Equations
2 Number Series & Missing Terms
3 Partnership, Mixture & Alligation
4 Time, Work, Pipes & Cisterns
5 Data Interpretation & Caselet

Advanced Reasoning:
6 Seating Arrangement
7 Floor & Box Puzzles
8 Input-Output & Machine Patterns
9 Critical Logic, Assumptions & Conclusions
10 Statement/Conclusion and Syllogism practice

Each lesson includes Marathi explanations, worked examples, five MCQs and answer explanations.
- Unlimited attempts
- Randomized question order
- 90% pass gate (5/5 in this five-question starter test)
- Sequential lesson unlock
- Progress saved in browser localStorage

Limitations:
- Starter module only; not a complete advanced Quant or Reasoning course.
- Does not yet include full-length multi-variable puzzles, timed sectional tests, exhaustive question banks or PYQs.
- Standalone; not integrated with Steps 1–12.
- Clearing browser data may erase progress.
- Question conventions may vary by exam; follow the relevant official notification and exam instructions.
- No paid API or service used.
