STAGE 22 — UNIFIED STUDENT EXPERIENCE / SHARED NAVIGATION

Added app-navigation.js and injected it into active root pages and learning modules.
Persistent bottom navigation provides:
- Home
- Progress (Mastery Centre)
- Study Plan (Student Profile)
- Settings

Implementation details:
- Links are resolved relative to the shared script, so nested module pages return to the correct root pages.
- Active section is highlighted on Home, Mastery Centre, Student Profile and Settings.
- Navigation is accessible via semantic nav and aria-current.
- Adds bottom padding so the bar does not cover the final page content.
- Service worker cache version bumped and navigation script added to precache.

Limitations:
- This is a consistent navigation layer, not a full redesign of every module.
- Some legacy modules may still have their own navigation and visual styles.
- This does not merge module content or progress records.
- Requires JavaScript; if disabled, each module's existing navigation remains.
- Browser end-to-end testing on Android and desktop is still required.
