SRUSHTI Step 2 – Syllabus Library

Open syllabus.html in a browser to browse exam-wise stages/sections and search common subject topics.
syllabus.json contains the structured data for future integration into the SRUSHTI app.

Important:
- This is an indicative starter syllabus map, not an official notification.
- Exact patterns and topics vary by recruitment year, post, and official notification.
- Check official SBI / IBPS / RBI / NABARD / SIDBI notifications before relying on exam dates, eligibility or final syllabus.
- No paid API, paid hosting, or paid service is included.
