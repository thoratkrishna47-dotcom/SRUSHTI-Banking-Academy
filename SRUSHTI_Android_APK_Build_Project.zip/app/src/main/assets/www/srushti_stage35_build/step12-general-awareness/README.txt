SRUSHTI Step 12 – General Awareness & Static GK

10 starter lessons:
1 Indian Constitution – Basics
2 Fundamental Rights, Duties & Directive Principles
3 Indian Parliament & Government
4 Indian Geography – Rivers, Mountains & States
5 Indian History – Ancient to Modern
6 Indian Economy – Basic Concepts
7 General Science – Physics & Chemistry
8 Biology, Environment & Biodiversity
9 National Symbols, Institutions & Important Days
10 General Awareness Study & Revision Strategy

Each lesson includes Marathi explanations, examples, five MCQs and answer explanations.
- Unlimited attempts
- Randomized question order
- 90% pass gate (5/5 in this five-question starter test)
- Sequential lesson unlock
- Progress saved in browser localStorage

Important limitations:
- Starter module only; not an exhaustive Static GK or General Awareness course.
- Some facts and administrative details can change. Verify current official information before exams.
- Does not include daily live current affairs or automatically updated data.
- No full-length timed mock, PYQs or cloud sync.
- Standalone; not integrated with Steps 1–11.
- Clearing browser data may erase progress.
- No paid API or service used.
