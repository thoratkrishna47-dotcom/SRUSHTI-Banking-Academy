SRUSHTI STAGE 5 — COMMON MASTERY ENGINE FOUNDATION

What is included:
- mastery-engine.js is loaded by the main learning module pages.
- It defines one common 90% pass rule.
- API: SRUSHTIMastery.recordAttempt(moduleId, topicId, score, total, meta)
- API: SRUSHTIMastery.canUnlock(moduleId, topicId)
- API: SRUSHTIMastery.getSummary()
- Attempts are kept on this device/browser in sru_mastery_ledger_v1.
- Unlimited attempts are retained (latest 100 per topic in this starter ledger).

IMPORTANT INTEGRATION STATUS:
This stage establishes the shared rule and callable API. Existing legacy quizzes have NOT all been rewritten to call recordAttempt yet. Their current in-module 90% checks continue to work as before. Therefore this stage does not yet make the central ledger authoritative for every module's unlock state. That requires adapting and testing each quiz's result handler.
- No cloud database, account/login, or paid service.
- Local data can be lost if browser site data is cleared.
