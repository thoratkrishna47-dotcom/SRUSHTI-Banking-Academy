SRUSHTI Step 8 – English Zero to Officer

Includes 10 English lessons:
1. Alphabet, vowels and consonants
2. Basic words and everyday vocabulary
3. Parts of Speech
4. Articles
5. Pronouns and subject–verb agreement
6. Verbs, tenses and sentence formation
7. Prepositions, conjunctions and sentence correction
8. Banking exam vocabulary and reading comprehension
9. Cloze test, fillers and error spotting
10. Descriptive English basics (email, letter, essay)

Each lesson includes Marathi explanation, examples and 5 MCQs with answer explanations.
- Unlimited attempts
- Randomized question order
- 90% threshold (5/5 needed in this 5-question starter quiz)
- Next lesson unlocks only after passing the previous lesson
- Progress saved locally in browser

Limitations:
- This is a starter learning module, not a complete English course or exhaustive exam question bank.
- Questions and explanations should be expanded and reviewed before high-stakes exam use.
- Speaking/listening practice, audio pronunciation, daily vocabulary feed and full-length exam tests are not included yet.
- Standalone module, not integrated with Steps 1–7.
- Browser data clearing may erase progress.
- No paid API or service used.
