SRUSHTI Step 16 – Smart Study Planner & Reminder Starter

Features:
- Add daily study tasks by subject, topic, start time and duration.
- Reminder lead time: at scheduled time, 5, 10 or 15 minutes before.
- Browser notification permission request.
- In-page reminder checks while the page is open.
- Mark tasks complete or missed; delete tasks.
- Daily dashboard, completion percentage and study minutes.
- Current and best streak, 7-day and 30-day consistency view.
- Daily report popup.
- Export local data as JSON backup.

Important limitations:
- This is a browser-based starter. It checks reminders every 15 seconds only while the page is running.
- It cannot guarantee alarms or notifications when the browser is closed, the phone is off, battery optimization suspends the browser, or notification permission is denied.
- Reliable background alarms on Android generally require a native Android app and appropriate permissions. Do not rely on this web module for critical reminders.
- Streak is based on at least one task marked complete on a calendar day.
- Study minutes are counted using the planned duration when a task is marked complete, not a stopwatch.
- Data is stored only in this browser/device; clearing browser data may erase it.
- Standalone module; not integrated with Steps 1–15.
- No paid API, server, hosting, subscription or external service used.
