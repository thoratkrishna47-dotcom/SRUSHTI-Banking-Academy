SRUSHTI – STEP 17: FREE VIDEO LEARNING LIBRARY
Starter version 1.0

COST: ₹0. No paid API, server, subscription, domain or hosting is required.

FILES
- index.html: searchable video library interface
- video_library.json: resource records

HOW TO USE ON ANDROID
1. Extract the ZIP file.
2. Keep index.html and video_library.json together in the same folder.
3. Open index.html in a browser. If the browser blocks loading the JSON file from local storage, use a free static hosting/PWA setup later or open through a local web server.
4. Search by subject/topic and tap Open YouTube resource.

ACCURACY LABELS
- Verified video: an exact video URL/title was surfaced during research.
- Verified channel: the channel identity and its stated subject coverage were checked.
- Search link: opens YouTube search results; it is NOT a claim that a particular video was verified.

INITIAL CURATION
- Adda247 Banking Exams: exact Percentage lecture.
- AffairsCloud: channel for daily/weekly/monthly current affairs and banking updates.
- Other beginner topics use clearly labelled YouTube search links until an exact free lecture is checked.

IMPORTANT LIMITATIONS
- This is a starter library, not a complete video course.
- YouTube availability, titles, language, duration and free access can change.
- Search results can include paid promotions or irrelevant videos; check before watching.
- No automatic video feed, watch-progress sync or video downloading is included.
- This module is standalone and is not integrated with Steps 1–16.
- No claim is made that the links are actual previous-year questions or official exam papers.

RESEARCH REFERENCES
- Adda247 official YouTube information: https://www.adda247.com/youtube.html
- Adda247 Percentage lecture: https://www.youtube.com/watch?v=DmI73tPddBk
- AffairsCloud channel: https://www.youtube.com/@AffairsCloud-Com
