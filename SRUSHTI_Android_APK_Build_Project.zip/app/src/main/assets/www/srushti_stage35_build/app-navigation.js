/* SRUSHTI Stage 22 — shared navigation. Uses same-origin local pages only. */
(function(){
'use strict';
if(document.getElementById('sru-global-nav')) return;
var script=document.currentScript;
if(!script || !script.src) return;
var base=new URL('./',script.src);
var items=[
 ['Home','index.html','home'],
 ['Progress','mastery-centre.html','progress'],
 ['Study Plan','student-profile.html','plan'],
 ['Settings','app-settings.html','settings']
];
var current=location.pathname.split('/').filter(Boolean).pop()||'index.html';
var active=current==='index.html' && location.pathname.endsWith('/')?'home':
 current==='index.html'?'home':
 current==='mastery-centre.html'?'progress':
 current==='student-profile.html'?'plan':
 current==='app-settings.html'?'settings':'';
var bar=document.createElement('nav');
bar.id='sru-global-nav';bar.setAttribute('aria-label','SRUSHTI main navigation');
var style=document.createElement('style');
style.textContent='#sru-global-nav{position:fixed;z-index:9998;left:0;right:0;bottom:0;display:flex;justify-content:center;gap:5px;padding:8px 8px calc(8px + env(safe-area-inset-bottom));background:rgba(255,255,255,.97);border-top:1px solid #dbe4ee;box-shadow:0 -4px 18px rgba(15,35,60,.10);font:600 12px Arial,sans-serif}#sru-global-nav a{flex:1;max-width:190px;text-align:center;text-decoration:none;color:#35516d;padding:10px 5px;border-radius:9px;white-space:nowrap}#sru-global-nav a[aria-current=page]{background:#174f82;color:#fff}body{padding-bottom:76px!important}@media(prefers-reduced-motion:no-preference){#sru-global-nav a{transition:background .15s ease}}';
document.head.appendChild(style);
items.forEach(function(item){
 var a=document.createElement('a');a.href=new URL(item[1],base).href;a.textContent=item[0];
 if(active===item[2])a.setAttribute('aria-current','page');
 bar.appendChild(a);
});
document.body.appendChild(bar);
})();
