SRUSHTI – STAGE 35: REMEDIAL MASTERY

What changed:
- Added a separate remedial retest ledger to mastery-engine.js.
- Stage 34 MCQ retest now submits per-module/topic results to that ledger.
- A remedial topic is marked passed only at >=90% and when every available MCQ question for that module/topic was included exactly once in that retest.
- Added stage35-remedial-mastery.html dashboard.
- Added Home link and updated service-worker cache.

Important safeguards:
- Remedial pass is separate from the original course-topic unlock. It does NOT mark the original topic as passed.
- Questions without saved MCQ options are not eligible for this MCQ retest.
- Retest result history is local to this browser/device. Keep regular backups.
- Runtime Android end-to-end testing has not been performed.
