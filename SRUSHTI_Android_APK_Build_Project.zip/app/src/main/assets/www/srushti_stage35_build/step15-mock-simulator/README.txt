SRUSHTI Step 15 – Full Mock Test Simulator (Starter)

Included:
- 30 original practice questions: 10 Quantitative Aptitude, 10 Reasoning, 10 English.
- Three separately timed sections; default 10 minutes each.
- Section timer automatically advances when time expires.
- Question palette with answered, marked-for-review and unanswered states.
- Clear answer, mark for review, save & next, jump to question.
- Submit confirmation and automatic final submission at the end of the final section timer.
- Correct/wrong/unattempted counts, section-wise score, answer explanations.
- Configurable negative marking: 0.25, 0.50 or none.
- One mark per correct answer; unanswered = zero.
- Last 10 mock summaries stored locally in the browser.

Important limitations:
- Starter simulator with 30 original practice questions, not an official full-length exam or authentic PYQ paper.
- Only Quant, Reasoning and English sections are included in this version.
- No server/cloud sync; clearing browser data may erase history.
- Timer runs while the page is open; browser/app closure or device sleep can affect timer behavior.
- Section navigation is forward-only after moving to the next section.
- Exam patterns, sectional timing and negative marking differ by recruitment notification. Configure according to the specific official notification before using it as an exam replica.
- Standalone module; not integrated with Steps 1–14.
- No paid API, hosting, subscription or service used.
