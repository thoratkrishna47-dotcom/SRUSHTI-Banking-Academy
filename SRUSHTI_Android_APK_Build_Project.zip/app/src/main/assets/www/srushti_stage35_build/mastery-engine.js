/* SRUSHTI Mastery Engine v1 — shared 90% rule, local-only */
(function(){
 'use strict';
 const KEY='sru_mastery_ledger_v1', PASS=90, WRONG_KEY='sru_wrong_answer_ledger_v1';
 const read=()=>{try{return JSON.parse(localStorage.getItem(KEY)||'{"version":1,"topics":{},"updatedAt":null}')}catch(e){return {version:1,topics:{},updatedAt:null}}};
 const write=x=>{x.updatedAt=new Date().toISOString();localStorage.setItem(KEY,JSON.stringify(x));return x};
 function recordAttempt(moduleId,topicId,score,total,meta){
   const n=Number(score), d=Number(total);
   if(!moduleId||!topicId||!Number.isFinite(n)||!Number.isFinite(d)||d<=0||n<0||n>d) return {ok:false,error:'Invalid attempt data'};
   const pct=n/d*100;
   const db=read(), id=String(moduleId)+':'+String(topicId), old=db.topics[id]||{moduleId:String(moduleId),topicId:String(topicId),attempts:[],attemptCount:0,passed:false,best:0};
   old.attempts=Array.isArray(old.attempts)?old.attempts:[];
   old.attemptCount=(Number(old.attemptCount)||old.attempts.length)+1;
   old.attempts.push({score:n,total:d,percent:Math.round(pct*100)/100,at:new Date().toISOString(),source:meta&&meta.source||'module'});
   old.attempts=old.attempts.slice(-100);
   old.best=Math.max(Number(old.best)||0,pct);
   old.passed=old.passed||pct>=PASS;
   old.lastPercent=Math.round(pct*100)/100;
   db.topics[id]=old;write(db);
   return {ok:true,passed:pct>=PASS,topicPassed:old.passed,best:old.best,attempts:old.attemptCount,retainedAttemptDetails:old.attempts.length,requiredPercent:PASS};
 }
 function readWrong(){try{const x=JSON.parse(localStorage.getItem(WRONG_KEY)||'[]');return Array.isArray(x)?x:[]}catch(e){return []}}
 function writeWrong(rows){localStorage.setItem(WRONG_KEY,JSON.stringify(rows.slice(-1000)));return rows.length}
 function recordWrongQuestion(item){
   if(!item||!item.question||!item.correctAnswer)return {ok:false,error:'Question and correct answer are required'};
   const rows=readWrong(), key=String(item.id||[item.moduleId,item.topicId,item.question].join('|'));
   const old=rows.find(x=>x.key===key&&x.status!=='Revised');
   if(old){old.lastSeen=new Date().toISOString();old.wrongCount=(old.wrongCount||1)+1;old.userAnswer=String(item.userAnswer??old.userAnswer??'');}
   else {const now=new Date();rows.push({key,moduleId:String(item.moduleId||'unknown'),topicId:String(item.topicId||'general'),subject:String(item.subject||'General'),question:String(item.question),userAnswer:String(item.userAnswer??''),correctAnswer:String(item.correctAnswer),explanation:String(item.explanation||''),source:String(item.source||'quiz'),status:'Pending',wrongCount:1,createdAt:now.toISOString(),lastSeen:now.toISOString(),revisionDays:[1,3,7,15,30],reviewedDays:[]});}
   writeWrong(rows);return {ok:true,total:rows.length};
 }
 function getWrongQuestions(){return readWrong().sort((a,b)=>String(b.lastSeen).localeCompare(String(a.lastSeen)));}
 function markWrongReviewed(key,day){const rows=readWrong(),x=rows.find(r=>r.key===String(key));if(!x)return false;const d=Number(day);if(![1,3,7,15,30].includes(d))return false;x.reviewedDays=Array.isArray(x.reviewedDays)?x.reviewedDays:[];if(!x.reviewedDays.includes(d))x.reviewedDays.push(d);if(x.reviewedDays.length>=5)x.status='Revised';writeWrong(rows);return true;}
 function submitQuizResult(moduleId,topicId,correct,total,meta){
   const details=Object.assign({source:'standard-quiz-result'},meta||{});
   const result=recordAttempt(moduleId,topicId,correct,total,details);
   if(result.ok&&Array.isArray(details.wrongQuestions))details.wrongQuestions.forEach(q=>recordWrongQuestion(Object.assign({moduleId,topicId,source:details.source},q)));
   return result;
 }
 function getModuleSummary(moduleId){
   const all=Object.values(read().topics).filter(t=>t.moduleId===String(moduleId));
   return {moduleId:String(moduleId),topicsAttempted:all.length,topicsPassed:all.filter(t=>t.passed).length,totalAttempts:all.reduce((n,t)=>n+(Number(t.attemptCount)||((t.attempts||[]).length)),0),topics:all};
 }
 function canUnlock(moduleId,topicId){
   const t=read().topics[String(moduleId)+':'+String(topicId)];
   return !!(t&&t.passed);
 }
 function syncLegacy(moduleId, progress){
   if(!progress || typeof progress!=='object') return 0;
   let imported=0, db=read();
   Object.keys(progress).forEach(topicId=>{
     const p=progress[topicId];
     if(p===true || (p && (p.passed===true || Number(p)>=90))){
       const id=String(moduleId)+':'+String(topicId);
       if(!db.topics[id]){
         db.topics[id]={moduleId:String(moduleId),topicId:String(topicId),attempts:[{score:100,total:100,percent:100,at:new Date().toISOString(),source:'legacy-progress-import'}],passed:true,best:100,lastPercent:100};
         imported++;
       }
     }
   });
   if(imported) write(db);
   return imported;
 }
 function canUnlockNext(moduleId, topicIds, index){
   if(index<=0) return true;
   for(let i=0;i<index;i++) if(!canUnlock(moduleId,topicIds[i])) return false;
   return true;
 }

 const RETEST_KEY='sru_retest_mastery_ledger_v1';
 function readRetests(){try{const x=JSON.parse(localStorage.getItem(RETEST_KEY)||'{"version":1,"topics":{}}');return x&&x.topics?x:{version:1,topics:{}}}catch(e){return {version:1,topics:{}}}}
 function recordRetestResult(moduleId,topicId,correct,total,eligibleKeys,testedKeys,meta){
   const c=Number(correct),t=Number(total),eligible=Array.isArray(eligibleKeys)?eligibleKeys.map(String):[],tested=Array.isArray(testedKeys)?testedKeys.map(String):[];
   if(!moduleId||!topicId||!Number.isFinite(c)||!Number.isFinite(t)||t<=0||c<0||c>t||!eligible.length||eligible.length!==t||tested.length!==t) return {ok:false,error:'Invalid retest data or incomplete coverage'};
   const uniqueEligible=[...new Set(eligible)].sort(),uniqueTested=[...new Set(tested)].sort();
   if(uniqueEligible.length!==t||uniqueTested.length!==t||uniqueEligible.some((k,i)=>k!==uniqueTested[i])) return {ok:false,error:'Retest must include every eligible question exactly once'};
   const wrong=readWrong(),valid=eligible.every(k=>wrong.some(q=>q.key===k&&String(q.moduleId)===String(moduleId)&&String(q.topicId)===String(topicId)));
   if(!valid) return {ok:false,error:'Question keys do not match this module/topic notebook'};
   const percent=Math.round(c/t*10000)/100,passed=percent>=PASS,db=readRetests(),id=String(moduleId)+':'+String(topicId),old=db.topics[id]||{moduleId:String(moduleId),topicId:String(topicId),attempts:[],attemptCount:0,passed:false,best:0};
   old.attempts=Array.isArray(old.attempts)?old.attempts:[];old.attemptCount=(Number(old.attemptCount)||old.attempts.length)+1;
   old.attempts.push({correct:c,total:t,percent,passed,coverageComplete:true,questionKeys:uniqueTested,at:new Date().toISOString(),source:(meta&&meta.source)||'wrong-answer-mcq-retest'});old.attempts=old.attempts.slice(-100);
   old.best=Math.max(Number(old.best)||0,percent);old.lastPercent=percent;old.passed=old.passed||passed;db.topics[id]=old;localStorage.setItem(RETEST_KEY,JSON.stringify(db));
   return {ok:true,passed,remedialPassed:old.passed,best:old.best,attempts:old.attemptCount,requiredPercent:PASS,coverageComplete:true};
 }
 function getRetestSummary(){const db=readRetests(),topics=Object.values(db.topics);return {requiredPercent:PASS,topicsAttempted:topics.length,topicsPassed:topics.filter(t=>t.passed).length,totalAttempts:topics.reduce((n,t)=>n+(Number(t.attemptCount)||0),0),topics};}

 function getSummary(){
   const topics=Object.values(read().topics);
   return {requiredPercent:PASS,topicsAttempted:topics.length,topicsPassed:topics.filter(t=>t.passed).length,totalAttempts:topics.reduce((n,t)=>n+(Number(t.attemptCount)||t.attempts.length),0),topics};
 }
 window.SRUSHTIMastery={requiredPercent:PASS,recordAttempt,submitQuizResult,recordWrongQuestion,getWrongQuestions,markWrongReviewed,recordRetestResult,getRetestSummary,canUnlock,canUnlockNext,syncLegacy,getSummary,getModuleSummary,exportData:()=>JSON.stringify(read(),null,2)};
})();