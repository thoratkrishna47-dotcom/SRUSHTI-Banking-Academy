STAGE 14 — SMART REVISION & WEAKNESS OVERVIEW

Mastery Centre now reads:
- Step 5 (sru_step5_records): counts due/overdue revision events using the saved revision dates and completion flags.
- Step 5: identifies latest recorded topic entries with score below 90% or confidence level 1.
- Step 16 (sru_step16): displays total planner tasks and a best-effort completed count when task records contain completed/status/done fields.

Important:
- This is a read-only summary; it does not edit Step 5 or Step 16 records.
- It does not automatically mark revision complete, create tasks, or infer study time.
- Existing browser-local storage must be on the same app origin to be visible.
- Planner completion count is best-effort because older task schema may not have an explicit completion property.
- Browser end-to-end verification with real saved records is still required.
