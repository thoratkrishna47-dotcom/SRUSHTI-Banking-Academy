STAGE 11 — CENTRAL 90% SEQUENTIAL UNLOCK (PARTIAL)

The common mastery engine supports:
- syncLegacy(moduleId, progress): imports previously passed local lesson records into the shared ledger.
- canUnlockNext(moduleId, topicIds, index): checks that every preceding topic is passed in the shared ledger.

Applied to sequential lesson modules:
Steps 8 English, 9 Reasoning, 10 Maths, 11 Banking Awareness, 12 General Awareness, 13 Advanced Maths & Reasoning.

Their lesson list and openLesson guards now use the common mastery ledger for sequential unlocks. Existing local passed records are imported once to avoid unexpectedly locking lessons already passed.
The modules retain their local progress records. This has not yet been applied to every module (e.g. Step 3, Step 19, Step 20, Step 21, Step 22, mock/practice modules).
Structural code update verified; full end-to-end browser testing with real user attempts is still required.
