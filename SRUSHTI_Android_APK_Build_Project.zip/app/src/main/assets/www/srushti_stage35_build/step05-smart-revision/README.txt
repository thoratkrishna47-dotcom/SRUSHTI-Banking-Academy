SRUSHTI – Step 5: Smart Revision & Weakness Dashboard

Included:
- Study log by subject and topic
- Score, time spent, and self-rated confidence
- Revision due dates at 1, 3, 7, 15, and 30 days
- Mark revision complete
- Weak-topic indicator when latest score is below 90% or confidence is low
- Remedial task suggestion
- Progress summary and JSON backup export

Important:
- This is a standalone starter module; it is not integrated with Steps 1–4 yet.
- It uses manually entered scores. It does not automatically read Step 4 test attempts.
- Local browser storage only; clearing browser data may erase records.
- No reminders/alarms are sent in the background. The module shows due revisions when opened.
- For reliable JSON loading, run from HTTPS hosting or a local web server; file:// may block fetch, though this module embeds its topic list.
- No paid APIs or services are used.
