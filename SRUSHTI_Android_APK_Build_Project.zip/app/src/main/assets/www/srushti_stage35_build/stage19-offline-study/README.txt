STAGE 19 — OFFLINE STUDY HUB & DOWNLOADABLE QUICK NOTES

Added offline-study-hub.html and a Home dashboard link.
Added six downloadable plain-text quick revision sheets:
- Maths Foundation
- Reasoning Foundation
- English Foundation
- Banking Awareness
- Computer Awareness
- General Awareness / Static GK

Service worker:
- Bumped cache version.
- Added Offline Study Hub and six notes to the install precache list.
- Existing module assets remain subject to the existing cache list and runtime caching.

How to use:
- Serve/install the PWA over HTTPS (or localhost for testing).
- Open the app online once; open modules once to cache runtime assets.
- Download TXT notes to the phone.
- Test offline after a successful online visit.

Limitations:
- This does not make all modules, YouTube links, live current affairs, recruitment pages or external resources fully offline.
- Some modules need additional JSON assets to be visited/cached before offline use; modules that were not opened may not be available.
- Opening index.html directly using file:// does not enable service workers.
- Progress remains local to this browser/device; no cloud sync.
- The text notes are concise starter revision sheets, not complete textbooks and not official exam syllabi.
- Browser end-to-end offline testing is still required.
