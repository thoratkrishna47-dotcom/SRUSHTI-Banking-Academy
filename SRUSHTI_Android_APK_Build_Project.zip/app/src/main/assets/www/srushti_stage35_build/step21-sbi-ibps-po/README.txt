SRUSHTI – STEP 21: SBI PO & IBPS PO EXAM-SPECIFIC PREPARATION
==============================================================

Files
- index.html: mobile-friendly lesson and quiz interface
- sbi_ibps_po_lessons.json: 12 starter lessons and 60 original practice MCQs

Included
- Common SBI PO / IBPS PO strategy
- Prelims Quant, Reasoning and English
- Mains Quant/DI, Reasoning, English writing and Awareness
- SBI PO-specific and IBPS PO-specific preparation notes
- Mock analysis and weekly study plan
- Marathi explanations, examples and checklists
- 5 MCQs per lesson, answer explanations, unlimited retakes
- Best score saved locally in browser; 90% mastery target

Important accuracy note
This is an original starter learning module, not an official SBI/IBPS publication.
It does not claim to reproduce authentic previous-year questions. Exam patterns,
stages, eligibility, dates, marks, timings, negative marking and selection rules
can change. Verify the relevant year's official notification:
SBI Careers: https://sbi.co.in/web/careers
IBPS: https://www.ibps.in/

How to use
Keep index.html and sbi_ibps_po_lessons.json in the same folder. Open using a
local web server or HTTPS hosting. Some Android browsers block fetch() from
file:// URLs, so opening the HTML directly may not load the JSON file.

Limitations
- Starter content only; not a complete course or exhaustive question bank.
- The MCQs are original general strategy questions, not exam-level full mocks.
- No live notification feed, cloud sync, AI tutor, alarms or verified video library.
- Progress is stored on this browser/device and can be lost if site data is cleared.
- Standalone module; not integrated with Steps 1–20.
- No paid API, hosting, subscription, server or external paid service is used.
