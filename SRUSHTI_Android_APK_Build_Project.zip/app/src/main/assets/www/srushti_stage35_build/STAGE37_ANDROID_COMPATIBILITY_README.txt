SRUSHTI — STAGE 37
Android Compatibility Check

Added:
- android-compatibility-check.html
- A local browser diagnostic for JavaScript, localStorage, JSON, service-worker API,
  notifications API, secure-context status, and page protocol.
- Link back to the SRUSHTI home page.

How to use:
1. Extract the complete ZIP folder.
2. Open android-compatibility-check.html from the same served app origin as index.html.
3. Review the results.
4. For complete testing, serve the entire folder over localhost or HTTPS.

Important limitations:
- This diagnostic is not an end-to-end test of every module.
- Opening files through Android content:// may block sibling resources.
- Service workers generally require HTTPS or localhost.
- Notification/background alarm behavior depends on browser, Android permissions,
  and whether the app is active.
- No APK/AAB is produced in this stage.
- No hosting, account, paid API, or subscription is included.
