SRUSHTI – Step 4: Question Bank & Mock Test (Starter Module)

Files:
- index.html: mobile-friendly practice and mock test interface
- question_bank.json: 20 sample questions across five subjects

Included:
- Randomized 10-question practice
- 20-question mock test
- Retest combines saved incorrect questions with fresh questions
- 90% pass threshold
- Explanations after submission
- Local progress and wrong-question tracking using browser localStorage
- Unlimited attempts

Important limitations:
- This is a standalone starter module, NOT yet integrated with Steps 1–3.
- The bank currently has only 20 sample questions. It is not a full competitive-exam question bank.
- Questions and explanations need expert review before exam use.
- Data stays in the current browser/device; clearing browser data can erase it.
- Open via a local web server or HTTPS hosting for reliable JSON loading. Opening index.html directly as file:// may block fetch().
- This module does not yet include sectional timers, mark-for-review, negative marking settings, previous-year papers, or cloud sync.
- No paid APIs/services are used.
