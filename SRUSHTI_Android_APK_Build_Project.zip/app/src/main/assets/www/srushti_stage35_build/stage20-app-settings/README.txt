STAGE 20 — APP SETTINGS, LANGUAGE PREFERENCE & DATA MANAGEMENT

Added app-settings.html and Home dashboard link.
Features:
- Saves preferred language (Marathi, English, Hindi).
- Saves preferred content explanation style (bilingual, Marathi-first, English-first).
- Shows browser notification permission and can request permission.
- Links to existing Full App Backup & Restore in Mastery Centre.
- Links to Student Profile and Offline Study Hub.
- Reset button deletes only sru_app_preferences_v1 and leaves learning progress untouched.
- About and local-storage privacy notes.

Important limitations:
- Saved language/content preference is currently a preference record only; it does not automatically translate every learning module.
- Notification permission does not guarantee background alarms when the browser is closed.
- Backup/restore behavior remains as implemented in Stage 15.
- No login, cloud sync or remote database.
- Browser end-to-end testing is still required.
