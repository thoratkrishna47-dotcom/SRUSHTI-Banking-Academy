SRUSHTI STAGE 7 — QUIZ ATTEMPT CONNECTIONS

Connected in this stage:
- Step 1 Starter subject tests
- Step 3 Foundation lessons
- Step 4 Question Bank practice
- Step 14 PYQ-pattern practice (original practice questions)
- Step 15 Full Mock Simulator

Each connected quiz reports an attempt to SRUSHTIMastery when that script is available. Step 15 reports correct-answer accuracy to the mastery ledger; its net score/negative marking remains in the mock's own history.

Cumulative connected quiz modules across Stages 6 and 7:
Steps 1, 3, 4, 8, 9, 10, 11, 12, 13, 14, 15, 19, 20, 21, 22.
This is 15 module pages, not all 23.

Important:
- The common ledger is an attempt-reporting layer, not yet the single authority for unlocking every module.
- Step 3's existing local completion condition remains; its quiz has only 3 questions, so 90% effectively requires 3/3.
- No cloud database/login. Data stays on the browser/device.
