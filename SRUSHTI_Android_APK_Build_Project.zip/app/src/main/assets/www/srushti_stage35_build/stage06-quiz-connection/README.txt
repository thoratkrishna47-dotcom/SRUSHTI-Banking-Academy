STAGE 6 — QUIZ RESULT CONNECTION
11 modules report each quiz attempt to the shared mastery ledger:
Steps 8,9,10,11,12,13,19,20,21,22 (10 modules). Step 8–13 are six modules; Steps 19–22 are four modules. Total 10.
Important: this is attempt reporting only. The legacy module-local unlock checks remain active and central enforcement is not yet authoritative for all topics. Steps 1–7, 14–17, 23–24 and any non-lesson test flows are not yet connected.
