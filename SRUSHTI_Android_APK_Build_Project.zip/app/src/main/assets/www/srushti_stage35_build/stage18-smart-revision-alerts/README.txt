STAGE 18 — SMART REVISION NOTIFICATIONS & REMINDER IMPROVEMENTS

Added revision-alerts.html with:
- Reads Step 5 records from sru_step5_records.
- Shows due/overdue revisions using the existing 1, 3, 7, 15, 30 day schedule.
- Allows marking a revision slot complete in the original Step 5 record.
- Reads today's pending study tasks from sru_step16.
- Optional browser notification permission and a manual Check Now control.
- Checks every 60 seconds while this page remains open.
- Sends at most one notification per day per category (revision/planner).
- Links from Home and Step 5.

Limitations:
- Browser notifications are not guaranteed when the page/browser is closed, device is asleep/off, or permission is denied.
- This is not a native Android alarm service and does not provide guaranteed background delivery.
- Uses existing local browser storage only; no server, paid API or cloud service.
- Notifications summarize outstanding items; user opens the page to see details.
- Browser end-to-end testing is still required.
