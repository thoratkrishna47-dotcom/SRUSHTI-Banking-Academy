STAGE 17 — DAILY STREAKS, ACHIEVEMENTS & MOTIVATION

Added motivation-achievements.html and links from Home and Student Profile.
Reads manually entered sessions from sru_goal_log_v1.
Calculates current streak (continues if last study day is today or yesterday), best streak, distinct study days and total logged hours.
Starter badges: first study day, 3 study days, 7/30 consecutive days, and 5/25/50/100 total hours.
Displays a rotating Marathi encouragement message and last-seven-day activity.
No shaming; missed days can be restarted.

Limitations:
- Only counts sessions manually entered in Stage 16 Student Profile; other module activity is not automatically included.
- Streak is based on calendar dates in device local storage; no cloud sync.
- Badges are calculated from the log when the page opens; no push notifications.
- Starter motivational messages and badge thresholds can be expanded later.
- Browser end-to-end testing is still required.
