SRUSHTI — STAGE 24: ANDROID PWA INSTALLATION PREPARATION

WHAT IS INCLUDED
- Updated Web App Manifest with app name, standalone display, portrait orientation, scope and icon declarations.
- Four PNG icons: 192x192 and 512x512, regular and maskable.
- Updated service-worker cache version and icon precache entries.
- This is an installable-PWA preparation package, NOT an Android APK.

HOW TO INSTALL ON ANDROID (AFTER HTTPS HOSTING)
1. Extract the ZIP and keep the complete folder structure unchanged.
2. Upload the complete extracted folder to a free HTTPS static hosting provider/account that you control. Do not upload only index.html.
3. Open the HTTPS site URL in Google Chrome on Android.
4. Wait for the Home page to load; then open a few modules once so their assets can be cached.
5. In Chrome, open the three-dot menu and choose "Install app" or "Add to Home screen" if offered.
6. Confirm the app name SRUSHTI and add/install it.
7. Open the installed icon and test Home, Progress, Study Plan, Settings and a sample quiz.
8. For offline testing, first visit required pages online, then turn off internet and test the pages that were cached.

IMPORTANT LIMITATIONS
- HTTPS hosting is required for reliable PWA installation and Service Worker/offline features. The ZIP cannot itself create a public HTTPS website.
- No APK or AAB has been built. Building a native Android package requires an Android build environment and signing process; this stage does not do that.
- Google Play publication may involve developer registration costs and is not part of this ₹0 package.
- Not every external video, current-affairs link, recruitment link, or module is available offline.
- Browser notifications/background alarms are not guaranteed when the browser is closed or the device is asleep.
- Local progress is stored on the same browser/device origin. Keep regular JSON backups.
- Do not change folder names or file paths after hosting.
- Static QA checks do not replace real Android runtime testing.

FREE-COST NOTE
This package adds no paid API, subscription, domain or hosting account. Hosting must be selected by the user; check current free-tier terms and limits before uploading.
