SRUSHTI Step 14 – Question Bank & PYQ-pattern Practice

Contents:
- 60 original practice MCQs across 6 subjects:
  Quantitative Aptitude, Reasoning, English, Banking Awareness,
  General Awareness / Static GK, Computer Awareness.
- Subject and exam filters.
- Randomized subject practice.
- 20-question mixed mock.
- Wrong-question retest using the last incorrect response.
- Answer explanations and device-local attempt tracking.
- Exam tags (indicative practice mapping only).

IMPORTANT PYQ ACCURACY:
The 60 questions are newly authored original practice questions inspired by common banking-exam patterns. They are NOT represented as actual previous-year questions. No authentic PYQ paper, year, shift or source is claimed in this starter module. Actual PYQs should be added only after verifying the official/authorized paper, exact wording, answer key, year and shift.

LIMITATIONS:
- Starter bank of 60 questions; not a large exhaustive bank.
- No official year/shift-wise PYQ archive yet.
- No negative marking, sectional timer, question palette or mark-for-review in this version.
- Exam tags are indicative, not a guarantee that a question appeared in that exam.
- Local browser storage only; clearing browser data may erase attempt history.
- Standalone; not integrated with Steps 1–13.
- No paid API, hosting, subscription or service used.
