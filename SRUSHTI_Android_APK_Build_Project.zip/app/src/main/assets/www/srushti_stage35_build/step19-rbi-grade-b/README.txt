SRUSHTI – STEP 19: RBI GRADE B GENERAL FOUNDATION
Starter version 1.0 | Cost: ₹0

FILES
- index.html
- rbi_grade_b_lessons.json
- README.txt

CONTENTS
10 Marathi foundation lessons and 50 original MCQs:
1. RBI Grade B exam stages
2. Indian economy basics
3. Inflation and price indices
4. RBI and monetary policy
5. Fiscal policy and budget
6. ESI: poverty, employment and inclusive development
7. Financial system and banking
8. Globalisation and external sector
9. Finance and Management
10. Descriptive English – answer writing practice

FEATURES
- Marathi explanations and examples
- 5 MCQs per lesson (50 total)
- answer explanations
- 90% pass gate; with 5 questions, all 5 must be correct
- unlimited attempts and sequential unlock
- browser localStorage progress
- RBI official notification link included

OFFICIAL REFERENCE
RBI Grade B (DR) Panel Year 2026, Advt. No. RBISB/DA/01/2026-27:
https://www.rbi.org.in/scripts/BS_ViewContent.aspx?Id=4997

SCOPE AND LIMITATIONS
- General cadre foundation only. DEPR and DSIM are separate specialist cadres and are not covered.
- Starter learning module, not a complete RBI Grade B course.
- Questions are original practice questions, not actual previous-year questions.
- Phase I Quant and Reasoning are not taught here; use the existing Maths and Reasoning modules.
- No full-length timed mock, descriptive answer evaluation, interview simulator or current-affairs feed.
- Exam pattern, eligibility, dates, marks and syllabus can change. Always read the latest RBI notification and Information Handout.
- Standalone; not integrated with Steps 1–18.
- Progress is stored on this browser/device; clearing browser data may erase it.
- No paid API, hosting, subscription or external paid service.
