SRUSHTI Step 11 – Banking Awareness Zero to Officer

10 starter lessons:
1 Banking Introduction
2 RBI – Reserve Bank of India
3 Bank Accounts & KYC
4 Deposits, Interest & Monetary Policy
5 Loans, Credit & NPA
6 Digital Payments: UPI, NEFT, RTGS, IMPS
7 Financial Inclusion & Government Schemes
8 Banking Institutions & Regulators
9 Banking Terms & Financial Literacy
10 Banking Exam Awareness Strategy & Current Updates

Each lesson includes Marathi explanations, examples, five MCQs and answer explanations.
- Unlimited attempts
- Randomized question order
- 90% pass gate (5/5 in this five-question starter test)
- Sequential lesson unlock
- Progress saved in browser localStorage

Important limitations:
- Starter learning module, not a complete or exhaustive Banking Awareness course.
- Current rates, office holders, scheme premiums/benefits, limits, dates and policy details change. Verify current facts from official RBI, Government of India, PIB, NABARD, SIDBI and relevant bank sources.
- Not a live current-affairs feed; no automatic updates.
- No full-length timed mock, PYQs or cloud sync.
- Standalone; not integrated with Steps 1–10.
- Clearing browser data may erase progress.
- No paid API or service used.
