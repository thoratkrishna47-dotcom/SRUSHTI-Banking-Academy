STAGE 21 — SECURITY, LOCAL DIAGNOSTICS & ERROR HANDLING

Added:
- app-security.js: local-only listeners for JavaScript errors and unhandled promise rejections.
- Keeps at most 20 brief error records in localStorage; attempts to strip URLs.
- Exposes a small SRUSHTISecurity helper for storage availability and viewing/clearing local errors.
- security-diagnostics.html: checks secure context, localStorage, Service Worker API, Notifications API, online/offline status and app origin.
- Added Home and Settings links.
- Added security script to active HTML pages.
- Updated service worker cache version and precache entries.

Important:
- This is basic client-side diagnostics, NOT a security audit, antivirus, encryption, login/authentication, or protection against a compromised device/browser.
- No data is sent to any server.
- Error log may contain short technical error messages; user can clear it.
- No passwords, OTPs, banking PINs or sensitive financial data should be entered into this learning app.
- HTTPS is needed for full PWA/service-worker behavior.
- Browser end-to-end testing is still required.
