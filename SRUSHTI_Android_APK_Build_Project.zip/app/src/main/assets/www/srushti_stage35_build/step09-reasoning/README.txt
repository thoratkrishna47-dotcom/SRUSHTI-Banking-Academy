SRUSHTI Step 9 – Reasoning Zero to Officer

10 starter lessons: Alphabet Series, Number Series, Coding-Decoding, Analogy & Classification, Blood Relations, Direction Sense, Syllogism, Inequality, Seating Arrangement & Puzzles, Banking Exam Mixed Reasoning Strategy.

Each lesson has Marathi explanations, examples, five MCQs and answer explanations.
- Unlimited attempts
- Randomized question order
- 90% pass gate (5/5 in this five-question starter test)
- Sequential lesson unlock
- Browser localStorage progress

Limitations:
- Starter module only; not a complete course or exhaustive question bank.
- No full-length timed mock, sectional timer, advanced multi-variable puzzles, PYQs or cloud sync.
- Standalone; not integrated with Steps 1–8.
- Clearing browser data may erase progress.
- Syllogism rules and question conventions should be aligned with each exam's accepted approach; this starter uses basic examples.
- No paid API or service used.
