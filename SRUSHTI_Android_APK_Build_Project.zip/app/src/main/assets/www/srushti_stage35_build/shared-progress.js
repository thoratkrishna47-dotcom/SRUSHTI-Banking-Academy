/* SRUSHTI unified progress adapter v1 — local device only */
(function () {
  'use strict';
  const WATCH = new Set(["srushtiState", "srushtiStep3", "sru_done", "sru_wrong", "sru_english_progress", "sru_reasoning_progress", "sru_maths_progress", "sru_banking_progress", "sru_gk_progress", "sru_advanced_progress", "sru_step14_stats", "sru_step15_history", "sru_step16", "sru_step5_records", "sru_ca_items", "sru_recruitment_records", "s23_reference_v1", "s24_dashboard_v1", "s19done", "s20done", "s21progress", "s22progress"]);
  const REG = 'sru_unified_registry_v1';
  const SCHEMA = 'sru_unified_progress_v1';
  const originalSet = Storage.prototype.setItem;
  const originalRemove = Storage.prototype.removeItem;

  function parse(raw, fallback) { try { return raw ? JSON.parse(raw) : fallback; } catch (_) { return fallback; } }
  function get(key, fallback) { return parse(localStorage.getItem(key), fallback); }
  function countPassed(key, value) {
    if (key === 'srushtiState') return Array.isArray(value && value.passed) ? value.passed.length : 0;
    if (key === 'srushtiStep3') return Object.values(value || {}).filter(v => Number(v) >= 90).length;
    if (key === 'sru_step14_stats' || key === 'sru_step15_history' || key === 'sru_step16' || key === 'sru_done' || key === 'sru_wrong') return 0;
    if (key === 's21progress' || key === 's22progress') return Object.values(value || {}).filter(v => Number(v) >= 90).length;
    if (key === 's19done' || key === 's20done') return Object.values(value || {}).filter(v => v === true || (v && v.passed === true)).length;
    return Object.values(value || {}).filter(v => v && typeof v === 'object' && v.passed === true).length;
  }
  function normalize(key, value) {
    const passed = countPassed(key, value);
    let attempts = 0, lastScore = null, topicCount = 0, mockCount = 0, taskCount = 0;
    if (key === 'sru_step15_history') mockCount = Array.isArray(value) ? value.length : 0;
    if (key === 'sru_step14_stats') {
      if (value && Array.isArray(value.attempts)) mockCount = value.attempts.length;
      else if (value && typeof value === 'object') mockCount = Object.keys(value).length;
    }
    if (key === 'sru_step16') taskCount = Array.isArray(value && value.tasks) ? value.tasks.length : 0;
    if (key === 'sru_step5_records' || key === 'sru_ca_items' || key === 'sru_recruitment_records') topicCount = Array.isArray(value) ? value.length : topicCount;
    if (key === 's23_reference_v1') {
      topicCount = ['vocabulary','formulas','wrong'].reduce((n,k)=>n+(Array.isArray(value && value[k])?value[k].length:0),0);
    }
    if (key === 's24_dashboard_v1') {
      topicCount = ['study','topics','mocks'].reduce((n,k)=>n+(Array.isArray(value && value[k])?value[k].length:0),0);
      mockCount = Array.isArray(value && value.mocks) ? value.mocks.length : mockCount;
    }
    if (key === 'srushtiState') topicCount = Array.isArray(value && value.passed) ? value.passed.length : 0;
    else if (value && typeof value === 'object' && !Array.isArray(value)) topicCount = Object.keys(value).length;
    if (key === 'sru_step15_history' && Array.isArray(value) && value.length) {
      attempts = value.length;
      lastScore = Number.isFinite(Number(value[0].score)) ? Number(value[0].score) : null;
    } else if (value && typeof value === 'object' && !Array.isArray(value)) {
      Object.values(value).forEach(v => {
        if (v && typeof v === 'object') {
          attempts += Number(v.attempts || 0);
          if (Number.isFinite(Number(v.last))) lastScore = Number(v.last);
          else if (Number.isFinite(Number(v.best))) lastScore = Number(v.best);
        }
      });
    }
    return { sourceKey:key, passedTopics:passed, topicRecords:topicCount, attempts, lastScore, mockCount, taskCount, updatedAt:new Date().toISOString() };
  }
  function writeSchema(key, raw) {
    if (!WATCH.has(key)) return;
    const value = parse(raw, {});
    const schema = get(SCHEMA, { version:1, modules:{}, updatedAt:null });
    schema.modules = schema.modules || {};
    schema.modules[key] = normalize(key, value);
    schema.updatedAt = new Date().toISOString();
    try { originalSet.call(localStorage, SCHEMA, JSON.stringify(schema)); } catch (_) {}
    const reg = get(REG, { events:[], keys:{} });
    reg.keys = reg.keys || {};
    reg.keys[key] = { updatedAt:schema.updatedAt, bytes:String(raw).length };
    reg.events = Array.isArray(reg.events) ? reg.events : [];
    reg.events.push({ key, at:schema.updatedAt });
    reg.events = reg.events.slice(-200);
    try { originalSet.call(localStorage, REG, JSON.stringify(reg)); } catch (_) {}
    try { window.dispatchEvent(new CustomEvent('sru-progress-updated', {detail:{key}})); } catch (_) {}
  }
  Storage.prototype.setItem = function(key, value) {
    originalSet.call(this, key, value);
    if (this === localStorage) writeSchema(String(key), String(value));
  };
  Storage.prototype.removeItem = function(key) {
    originalRemove.call(this, key);
    if (this === localStorage && WATCH.has(String(key))) writeSchema(String(key), '{}');
  };
  // Import existing saved progress when the page first loads after upgrade.
  WATCH.forEach(key => { const raw = localStorage.getItem(key); if (raw !== null) writeSchema(key, raw); });
  window.SRUSHTIProgress = {
    registryKey:REG, schemaKey:SCHEMA,
    getRegistry:()=>get(REG,{events:[],keys:{}}),
    getUnified:()=>get(SCHEMA,{version:1,modules:{},updatedAt:null}),
    watchedKeys:Array.from(WATCH)
  };
})();