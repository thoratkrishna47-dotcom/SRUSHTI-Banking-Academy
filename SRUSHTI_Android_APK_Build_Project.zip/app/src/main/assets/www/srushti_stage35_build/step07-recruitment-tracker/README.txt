SRUSHTI Step 7 – Official Recruitment Tracker

Included:
- Add recruitment records for SBI, IBPS, RBI, NABARD, SIDBI and other banks
- Track status: Awaited, notification, application, exam, admit card, result, completed
- Store vacancy, eligibility, age-limit notes, dates, fee, official application URL, notification PDF/source URL
- Search and filter records
- Dashboard counts and JSON backup
- Official career-site quick links

Important limitations:
- This module does NOT automatically fetch or verify recruitment notifications.
- No sample dates, vacancy counts, fees or eligibility claims are prefilled.
- User must check each official notification and enter verified details.
- Recruitment conditions change by notification, category and year; the official PDF is authoritative.
- Standalone module, not yet integrated with Steps 1–6.
- Data is stored in local browser storage and may be lost if browser data is cleared.
- No paid API, subscription or hosting is required for this module.
