STAGE 25 — ANDROID INSTALL READINESS CHECKER

What changed:
- Added install-readiness.html with browser-side checks for secure context, manifest, manifest icons, service worker support/registration, online state and standalone display.
- Added an Install App button that appears only when the browser fires beforeinstallprompt.
- Added links from Home and App Settings.
- Updated service-worker cache version and precache list.

Important limitations:
- This is a readiness checker, not an APK/AAB builder.
- PWA installation generally requires HTTPS (localhost is a development exception).
- The user must publish the complete folder to an HTTPS static host. No hosting is included or performed.
- Install prompts vary by Android/browser version. If no prompt appears, use Chrome menu > Install app / Add to Home screen if offered.
- Browser notifications/background alarms are not guaranteed when the app is closed.
- No paid service, API, account, server, domain, ads or subscription was added.

Manual Android test still required after HTTPS hosting.
