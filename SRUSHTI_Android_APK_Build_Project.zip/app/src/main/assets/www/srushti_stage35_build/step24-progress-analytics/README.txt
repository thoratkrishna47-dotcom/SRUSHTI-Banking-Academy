SRUSHTI – STEP 24: COMPLETE PROGRESS DASHBOARD & PERFORMANCE ANALYTICS
======================================================================

Files
- index.html: dashboard application
- README.txt: setup and limitations

Sections
1. Overview: study hours, completed topics, mock count, average mock percentage,
   number of distinct study dates, weekly study-time bars, subject study totals
   and next actions based on manually entered topic statuses.
2. Study Log: date, subject, minutes, topic and notes.
3. Topic Tracker: subject, topic, status and best score.
4. Mock Scores: exam, test type, date, marks obtained, maximum marks and analysis.
5. Backup: export/import JSON.

How to use
Open index.html in a modern browser. This module does not fetch a JSON file and
can run as a standalone local HTML page. Add your study entries and test scores
manually. Export backup regularly.

Important limitations
- Standalone module; it does not automatically read or combine progress from Steps 1–23.
- Study hours, topic completion and mock scores are only as accurate as manual entries.
- "Study days logged" counts distinct dates with at least one study entry; it is
  not a consecutive-day streak.
- Weekly chart shows the last seven calendar days and subject totals are based
  on study log entries. It does not predict exam results.
- Data is saved only in this browser/device. Clearing browser data can erase it.
- No cloud sync, AI analysis, background alarms or live exam data.
- No paid API, hosting, subscription, server or external paid service is used.
