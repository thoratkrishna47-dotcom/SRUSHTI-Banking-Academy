SRUSHTI Step 3 – Foundation Lesson Pack

Open lessons.html in a browser. Choose a subject, read a foundation lesson, then take the sample topic quiz.
Progress is saved locally in the same browser using localStorage.

Includes 15 starter lessons across Maths, Reasoning, English, General & Banking Awareness, and Computer Awareness.
Each lesson includes a Marathi explanation, example, and 3 sample questions.

Important:
- This is a small starter pack, not a complete banking exam course or a validated large question bank.
- The 90% pass rule is implemented in this lesson pack: only scores >=90% mark a topic as passed.
- Progress is local to this browser/device and can be lost if site data is cleared.
- No paid APIs, hosting, or subscriptions are used.
