SRUSHTI – STEP 22: COMPUTER AWARENESS ZERO TO OFFICER
=====================================================

Contents
- index.html: mobile-friendly lesson and quiz interface
- computer_awareness.json: 10 lessons and 50 original MCQs

Lessons
1. Computer Fundamentals
2. Hardware – CPU, Input & Output Devices
3. Memory & Storage
4. Software & Operating System
5. Office Applications & Shortcuts
6. Internet, Browser & Email
7. Computer Networks
8. Cyber Security & Safe Banking
9. Database & Data Management
10. Banking Technology & Digital Payments

Features
- Marathi explanations and examples
- Key terms for revision
- 5 MCQs per lesson with explanations
- Unlimited attempts
- 90% mastery target (5/5 in this starter test)
- Best score and passed-lesson count saved in browser localStorage

How to open
Keep index.html and computer_awareness.json in the same folder. Use HTTPS
hosting or a local web server. Some Android browsers block JSON fetch from
file:// URLs, so opening index.html directly may not load the lessons.

Limitations
- Starter module, not a complete computer course or exhaustive question bank.
- Questions are original practice questions, not authentic previous-year questions.
- No live updates, cloud sync, AI tutor, alarms or server.
- Progress is device/browser-local and may be lost if site data is cleared.
- Standalone module; not integrated with Steps 1–21.
- Banking technology rules and payment procedures can change; verify current
  information through official RBI/NPCI/bank sources.
- No paid API, hosting, subscription or external paid service used.
