STAGE 15 — FULL LOCAL BACKUP & RESTORE

Added to Mastery Centre:
- Download Full Backup exports localStorage keys whose names start with sru (case-insensitive) or s24_.
- JSON includes app identifier, backup type/version, timestamp, origin, key count and string values.
- Restore validates the file format, version, key names and value types before writing.
- User confirmation is required; matching keys are overwritten. Keys absent from the backup are preserved.
- Page reloads after restore so the dashboard can reread saved data.

Important limitations:
- This is browser-local backup, not cloud sync.
- Restore must be done on the same app origin for modules to read the data.
- Does not export browser permissions, installed PWA files, service worker cache, downloaded files or YouTube offline content.
- Only app-prefixed localStorage keys are included; other website data is excluded.
- Keep a copy of the JSON somewhere safe. Importing untrusted JSON is not recommended.
- Browser end-to-end file picker and restore testing is still required.
