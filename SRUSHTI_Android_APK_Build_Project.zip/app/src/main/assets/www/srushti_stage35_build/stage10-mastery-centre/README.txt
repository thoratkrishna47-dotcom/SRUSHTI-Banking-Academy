STAGE 10 — COMMON MASTERY CENTRE

Added mastery-centre.html and a link on the main dashboard.
Shows topic-wise attempts recorded by the existing Common Mastery Engine, pass status at 90%, best/latest score, and last attempt time.
Includes module/topic search, passed/pending filters, and JSON export.
Only records submitted by connected modules appear. This screen does not force all modules to use central unlock checks; unlock enforcement remains a future integration task.
Data stays in browser localStorage. Export is the user's manual backup.
