SRUSHTI STAGE 8 — REMAINING MODULE DATA COVERAGE

Added these existing local data keys to the shared progress adapter:
- Step 5 study/revision records
- Step 6 current affairs entries
- Step 7 recruitment tracker records
- Step 23 vocabulary/formula/wrong-answer reference book
- Step 24 progress analytics records

Step 16 planner data was already watched by the shared adapter.
Step 6 monthly current-affairs quiz now reports its quiz attempt to the shared mastery ledger when the user submits a non-empty quiz.

These are data coverage connections, not all quiz/mastery attempts. Steps 5 and 7 store user-created content/records; Step 5 and Step 24 contain study logs. They are summarized as tracked records, not passed lessons.
No user data is uploaded or sent to a server. Data remains local to the same browser origin.
