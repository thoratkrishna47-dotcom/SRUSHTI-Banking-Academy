SRUSHTI Step 10 – Maths Zero to Officer

10 starter lessons:
1 Basic Numbers & Place Value
2 Addition, Subtraction, Multiplication & Division
3 Tables, Fractions & Decimals
4 BODMAS & Simplification
5 Factors, Multiples, HCF & LCM
6 Percentage
7 Ratio, Proportion & Average
8 Profit, Loss & Discount
9 Simple Interest, Time & Work, Speed
10 Data Interpretation & Banking Exam Quant Strategy

Each lesson has Marathi explanations, worked examples, five MCQs and answer explanations.
- Unlimited attempts
- Randomized question order
- 90% pass gate (5/5 in this five-question starter test)
- Sequential lesson unlock
- Progress saved in browser localStorage

Limitations:
- Starter module only; not a complete mathematics course or exhaustive banking exam question bank.
- Advanced algebra, quadratic equations, number series, partnership, mixture, pipes/cisterns, trains, boats/streams and advanced DI need further modules.
- No full-length timed mock, sectional timer, PYQs or cloud sync.
- Standalone; not integrated with Steps 1–9.
- Clearing browser data may erase progress.
- No paid API or service used.
