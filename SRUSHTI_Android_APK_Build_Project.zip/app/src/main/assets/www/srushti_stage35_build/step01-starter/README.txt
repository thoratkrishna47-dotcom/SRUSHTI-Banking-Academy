SRUSHTI Banking Academy – zero-cost starter prototype

Files:
- index.html: responsive study dashboard, sample foundation lessons and 10-question tests
- manifest.webmanifest: PWA metadata
- sw.js: basic offline cache

How to try:
1. Extract this ZIP.
2. Open index.html in a browser to preview. Progress is stored locally in that browser.
3. For installable PWA/offline service-worker behavior, serve these files over HTTPS or localhost; service workers do not run from file://.
4. No paid API, server, domain, subscription, or database is used by this prototype.

Important limitations:
- This is a starter prototype, not a complete production app.
- Lessons and questions are sample content, not a full exam syllabus/question bank.
- Browser notifications/alarms are not implemented; reliable background alarms need a native Android app and OS permissions.
- Official recruitment dates, current affairs, and exact YouTube lesson links are not populated until verified from authoritative sources.
- Local progress remains on this device/browser and can be lost if browser data is cleared.
