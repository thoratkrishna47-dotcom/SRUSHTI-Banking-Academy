/* SRUSHTI Stage 21: local-only diagnostics and safe error reporting. No network calls. */
(function(){
'use strict';
var KEY='sru_local_error_log_v1',MAX=20;
function clean(v){return String(v||'Unknown app error').replace(/https?:\/\/\S+/g,'[link]').slice(0,220)}
function save(type,message){
 try{
  var a=JSON.parse(localStorage.getItem(KEY)||'[]');if(!Array.isArray(a))a=[];
  a.push({type:String(type).slice(0,40),message:clean(message),time:new Date().toISOString()});
  localStorage.setItem(KEY,JSON.stringify(a.slice(-MAX)));
 }catch(e){}
}
window.addEventListener('error',function(e){save('JavaScript',e.message||'Script error');});
window.addEventListener('unhandledrejection',function(e){save('Promise',e.reason&&e.reason.message?e.reason.message:e.reason);});
window.SRUSHTISecurity={
 version:'stage21-local-diagnostics',
 getErrors:function(){try{var a=JSON.parse(localStorage.getItem(KEY)||'[]');return Array.isArray(a)?a:[]}catch(e){return[]}},
 clearErrors:function(){try{localStorage.removeItem(KEY);return true}catch(e){return false}},
 storageAvailable:function(){try{var k='__sru_test__';localStorage.setItem(k,'1');localStorage.removeItem(k);return true}catch(e){return false}}
};
})();
