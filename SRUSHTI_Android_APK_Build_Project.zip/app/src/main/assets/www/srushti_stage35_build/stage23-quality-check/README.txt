STAGE 23 — APP TESTING & QUALITY CHECK

Added quality-check.html with the static QA report and Android/manual test checklist.
Added links from Home and App Settings.
Updated service-worker cache version and precache list.

Static checks run during build:
- 31 active HTML pages inspected.
- Shared navigation script reference present on all 31 pages.
- 0 missing local JavaScript script files.
- 0 unresolved static local href/src references (dynamic template expressions excluded).
- 18 JSON files parsed successfully.
- Main navigation destinations and service-worker precache entry checked.
- ZIP archive integrity checked after packaging.

Not performed:
- No full browser automation or Android device end-to-end testing.
- Quiz 90% pass/unlock behavior, retest, mock timer, backup restore, notifications and offline PWA must still be manually tested.
- Passing static checks does not prove all app features are bug-free.
