SRUSHTI – STEP 23: SMART STUDY REFERENCE BOOKS
================================================

Files
- index.html: mobile-friendly interface
- reference_data.json: 20 English vocabulary entries and 20 Quant formulas
- README.txt: setup and limitations

Sections
1. Vocabulary Book: English word, Marathi meaning, example sentence, synonym; search and add custom words.
2. Formula Book: topic, formula, notes; search and add custom formulas.
3. Wrong Answer Notebook: record subject, topic, question, wrong answer, correct answer, reason and revision note; mark revised/pending.
4. Backup & Export: export all local data to JSON and import a previous backup.

How to use
Keep index.html and reference_data.json in the same folder. Open via HTTPS
or a local web server. Some mobile browsers block JSON fetch from file:// URLs.

Important limitations
- This is a starter reference library, not a complete vocabulary dictionary or formula encyclopedia.
- The user must enter their own wrong questions; this module does not automatically import results from Steps 4, 14 or 15.
- Data is saved only in this browser/device. Export backups regularly; clearing site data may erase entries.
- Standalone module; not integrated with Steps 1–22.
- Formulas are study references; verify the correct formula and conditions for each question.
- No paid API, hosting, subscription, server or external paid service is used.
