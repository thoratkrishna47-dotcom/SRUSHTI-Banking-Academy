SRUSHTI – STEP 18: COMPUTER AWARENESS ZERO TO OFFICER
Starter version 1.0 | Cost: ₹0

CONTENTS
- index.html: lesson and quiz interface
- computer_lessons.json: 10 lessons and 50 MCQs
- README.txt: instructions and limitations

TOPICS
1. Computer basics and IPO cycle
2. Hardware and Software
3. CPU, ALU, Control Unit and Registers
4. RAM, ROM, Cache and Storage
5. Input and Output Devices
6. Operating System and File Management
7. Internet, Browser, Email and Networking
8. MS Office – Word, Excel and PowerPoint
9. Cyber Security, Virus and Safe Practices
10. Digital Banking, UPI and Payment Safety

FEATURES
- Marathi explanations and examples
- Five MCQs per lesson (50 total)
- Answer explanations
- Randomness is not implemented in this starter quiz; question order is fixed.
- 90% pass threshold; with five questions, all five must be correct.
- Unlimited attempts and sequential lesson unlock
- Progress stored in browser localStorage

HOW TO USE
1. Extract the ZIP.
2. Keep index.html and computer_lessons.json in the same folder.
3. Open index.html in a modern browser.
4. If local file restrictions prevent loading the JSON file, serve the folder using a free local web server or free static hosting. No paid hosting is required.

IMPORTANT LIMITATIONS
- Starter module only; not a complete/exhaustive Computer Awareness course.
- Only 50 original practice MCQs; not authentic previous-year questions.
- No timed test, negative marking, PYQ archive, audio lessons or cloud sync.
- Progress is stored on this device/browser; clearing browser data may erase it.
- This is standalone and is not integrated with Steps 1–17.
- Verify changing digital payment and cybersecurity guidance with official RBI/NPCI/bank sources.
- No paid API, hosting, subscription or external service is used.
