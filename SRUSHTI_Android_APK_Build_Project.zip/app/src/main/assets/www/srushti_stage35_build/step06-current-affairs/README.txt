SRUSHTI Step 6 – Daily & Monthly Current Affairs

Included:
- Add daily current-affairs entries by date and category
- Save headline, short notes, and source URL
- Optionally add one MCQ with four options to each entry
- Search and filter notes by month
- Monthly quiz built from the quiz questions you entered for that month
- Local browser storage

Limitations:
- No automatic/live news feed and no daily update service.
- No current-events content has been preloaded; add verified updates yourself.
- Verify facts and source links, preferably with official sources, before exam preparation.
- Monthly quiz only includes entries that contain a complete MCQ.
- This module is standalone and not integrated with Steps 1–5.
- Data remains on this browser/device and may be lost if browser data is cleared.
- No paid API, hosting, or subscription is required for this module.
