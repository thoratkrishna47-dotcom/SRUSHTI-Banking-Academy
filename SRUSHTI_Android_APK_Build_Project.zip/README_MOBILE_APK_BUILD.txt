SRUSHTI ANDROID APK BUILD PROJECT

What this is:
- An Android WebView wrapper project containing the current SRUSHTI web/PWA files.
- A GitHub Actions workflow that can build a DEBUG APK in the cloud when the project is pushed to a GitHub repository.

What it is NOT:
- No APK has been built yet.
- This is not a Play Store release or a production-signed release.
- It does not prove all web app functions work on Android.
- It has no custom launcher icon yet.

Free build route:
1. Create a GitHub account if you do not already have one.
2. Create a new repository named srushti-android.
3. Upload all extracted project files and folders from this ZIP to the repository root (not the ZIP itself).
4. Open the repository's Actions tab.
5. Run "Build SRUSHTI APK" using Run workflow, or push to main.
6. When the workflow finishes, open its run and download artifact "SRUSHTI-debug-APK".
7. Extract the artifact ZIP and install app-debug.apk on Android, allowing installation from that source if Android asks.

Cost:
- Uses GitHub Actions free allowance, subject to GitHub account and usage limits.
- No paid API or domain is included. Avoid enabling paid services.

Important technical limitation:
- This wraps the current HTML app in a WebView using file:///android_asset.
- Service worker/PWA installation APIs do not work the same way under file://.
- Browser notifications/background alarms may not work in this wrapper.
- Local file storage is app-private and may not be shared with Chrome.
- Validate all screens and quiz behavior on device before relying on it.
